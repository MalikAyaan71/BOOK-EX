
// Select the database to use.

use('newADCS2A');


db.newperson.find();

db.newADCS2A.insertMany ([
  {
    "name": "Susheel Kumar",
    "Roll_NO": "230494",
    "age": 19,
    "gender": "Male",
  },

  {
    "name": "Talha Shabbir",
    "Roll_NO": "230484",
    "age": 21,
    "gender": "Male",
  },

  {
    "name": "Airisam",
    "Roll_NO": "230456",
    "age": 22,
    "gender": "Male",
  }

]);

db.newADCS2A.find(
{
    $or : [
        {"age " : 19}, {"gender": "Male"} 
    ]
}
);

